﻿export default interface IDept {
    dno?: any | null,
    dname: string,
    loc: string
}