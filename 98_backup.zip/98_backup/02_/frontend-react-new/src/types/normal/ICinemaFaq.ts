export default interface ICinemaFaq {
    cfno?: any | null,
    question: string,
    answer: string,
    sortOrder: number | string
}