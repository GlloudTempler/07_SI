export default interface IEmp {
    eno?: any | null,
    ename: string,
    job: string,
    manager: number | string,
    hiredate: string,
    salary: number | string,
    commission: any | null,
    dno: number | string
}